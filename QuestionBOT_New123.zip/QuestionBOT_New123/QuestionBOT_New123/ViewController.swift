//
//  ViewController.swift
//  QuestionBOT_New
//
//  Created by iOS Lab on 22/06/24.
//

import UIKit

class ViewController: UIViewController {
    
    let keywords = ["desejo", "ajuda", "conselho", "gênio"]
    let messages = [
        "desejo": "Seu desejo é uma ordem!",
        "ajuda": "Estou aqui para ajudar!",
        "conselho": "Aqui está um conselho sábio: sempre acredite em si mesmo.",
        "gênio": "Você encontrou o gênio da lâmpada!"
    ]
    
    
    @IBOutlet weak var textInfo: UILabel!
    @IBOutlet weak var textWish: UITextField!
    @IBOutlet weak var buttonDo: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func buttonPressed() {
        guard let searchText = textWish.text?.lowercased() else { return }
        
        var alertTitle = ""
          var alertMessage = ""
        
        var keywordFound = false
        for keyword in keywords {
            if searchText.contains(keyword){
                alertTitle = "Alerta!"
                alertMessage = messages[keyword]!
                keywordFound = true
                break
            }
        }
        if !keywordFound {
            alertTitle = "Infelizmente não entendi o que você quis dizer com isso aqui:"
            alertMessage = "\(searchText)"
        }
        
        let alertController = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: .alert)

        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)

        present(alertController, animated: true, completion: nil)

    }
}


 

